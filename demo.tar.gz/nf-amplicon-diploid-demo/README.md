# nf-amplicon-diploid demo data

Small test dataset containing amplicon reads and reference sequence derived from wf-amplicon demo data.
